<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_room'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'room'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $room_id=$_SESSION['id_upd'];
                      
$floor_number = $_POST['txt_floor_number'];
$flat_tv = $_POST['txt_flat_tv'];
$wifi = $_POST['txt_wifi'];
$shower = $_POST['txt_shower'];
$heating = $_POST['txt_heating'];
$cable_channel = $_POST['txt_cable_channel'];
$towels = $_POST['txt_towels'];
$toilet_papers = $_POST['txt_toilet_papers'];
$number_beds = $_POST['txt_number_beds'];
$price_per_night = $_POST['txt_price_per_night'];
$smocking = $_POST['txt_smocking'];
$status = $_POST['txt_status'];
$max_adults = $_POST['txt_max_adults'];
$max_children = $_POST['txt_max_children'];


$upd_obj->update_room($floor_number, $flat_tv, $wifi, $shower, $heating, $cable_channel, $towels, $toilet_papers, $number_beds, $price_per_night, $smocking, $status, $max_adults, $max_children,$room_id);
unset($_SESSION['table_to_update']);
}}else{$floor_number = $_POST['txt_floor_number'];
$flat_tv = $_POST['txt_flat_tv'];
$wifi = $_POST['txt_wifi'];
$shower = $_POST['txt_shower'];
$heating = $_POST['txt_heating'];
$cable_channel = $_POST['txt_cable_channel'];
$towels = $_POST['txt_towels'];
$toilet_papers = $_POST['txt_toilet_papers'];
$number_beds = $_POST['txt_number_beds'];
$price_per_night = $_POST['txt_price_per_night'];
$smocking = $_POST['txt_smocking'];
$status = $_POST['txt_status'];
$max_adults = $_POST['txt_max_adults'];
$max_children = $_POST['txt_max_children'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_room($floor_number, $flat_tv, $wifi, $shower, $heating, $cable_channel, $towels, $toilet_papers, $number_beds, $price_per_night, $smocking, $status, $max_adults, $max_children);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
room</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_room.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->


      <?php
            include 'admin_header.php';
                ?>

  <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog--><div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 room saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered new_data_title">  room Registration </div>
 <table class="new_data_table">


<tr><td><label for="txt_floor_number">Floor Number </label></td><td> <input type="text"     name="txt_floor_number" required id="txt_floor_number" class="textbox" value="<?php echo trim(chosen_floor_number_upd());?>"   />  </td></tr>
<tr><td><label for="txt_flat_tv">Flat Tv </label></td><td> <input type="text"     name="txt_flat_tv" required id="txt_flat_tv" class="textbox" value="<?php echo trim(chosen_flat_tv_upd());?>"   />  </td></tr>
<tr><td><label for="txt_wifi">Wifi </label></td><td> <input type="text"     name="txt_wifi" required id="txt_wifi" class="textbox" value="<?php echo trim(chosen_wifi_upd());?>"   />  </td></tr>
<tr><td><label for="txt_shower">shower </label></td><td> <input type="text"     name="txt_shower" required id="txt_shower" class="textbox" value="<?php echo trim(chosen_shower_upd());?>"   />  </td></tr>
<tr><td><label for="txt_heating">Heating </label></td><td> <input type="text"     name="txt_heating" required id="txt_heating" class="textbox" value="<?php echo trim(chosen_heating_upd());?>"   />  </td></tr>
<tr><td><label for="txt_cable_channel">Cable channel </label></td><td> <input type="text"     name="txt_cable_channel" required id="txt_cable_channel" class="textbox" value="<?php echo trim(chosen_cable_channel_upd());?>"   />  </td></tr>
<tr><td><label for="txt_towels">Towels </label></td><td> <input type="text"     name="txt_towels" required id="txt_towels" class="textbox" value="<?php echo trim(chosen_towels_upd());?>"   />  </td></tr>
<tr><td><label for="txt_toilet_papers">Toilet Papers </label></td><td> <input type="text"     name="txt_toilet_papers" required id="txt_toilet_papers" class="textbox" value="<?php echo trim(chosen_toilet_papers_upd());?>"   />  </td></tr>
<tr><td><label for="txt_number_beds">Number of Beds </label></td><td> <input type="text"     name="txt_number_beds" required id="txt_number_beds" class="textbox" value="<?php echo trim(chosen_number_beds_upd());?>"   />  </td></tr>
<tr><td><label for="txt_price_per_night">Price Per Night </label></td><td> <input type="text"     name="txt_price_per_night" required id="txt_price_per_night" class="textbox" value="<?php echo trim(chosen_price_per_night_upd());?>"   />  </td></tr>
<tr><td><label for="txt_smocking">Smoking </label></td><td> <input type="text"     name="txt_smocking" required id="txt_smocking" class="textbox" value="<?php echo trim(chosen_smocking_upd());?>"   />  </td></tr>
<tr><td><label for="txt_status">Status </label></td><td> <input type="text"     name="txt_status" required id="txt_status" class="textbox" value="<?php echo trim(chosen_status_upd());?>"   />  </td></tr>
<tr><td><label for="txt_max_adults">max_adults </label></td><td> <input type="text"     name="txt_max_adults" required id="txt_max_adults" class="textbox" value="<?php echo trim(chosen_max_adults_upd());?>"   />  </td></tr>
<tr><td><label for="txt_max_children">Max Children </label></td><td> <input type="text"     name="txt_max_children" required id="txt_max_children" class="textbox" value="<?php echo trim(chosen_max_children_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_room" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">room List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_room();
                    $obj->list_room($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>


<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
<script>
    var txt_update = $('#txt_shall_expand_toUpdate').val();
    if (txt_update != '') {
            }
</script>
</body>
</hmtl>
<?php
function chosen_floor_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $floor_number = new multi_values();
               return $floor_number->get_chosen_room_floor_number($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_flat_tv_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $flat_tv = new multi_values();
               return $flat_tv->get_chosen_room_flat_tv($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_wifi_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $wifi = new multi_values();
               return $wifi->get_chosen_room_wifi($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_shower_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $shower = new multi_values();
               return $shower->get_chosen_room_shower($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_heating_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $heating = new multi_values();
               return $heating->get_chosen_room_heating($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_cable_channel_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $cable_channel = new multi_values();
               return $cable_channel->get_chosen_room_cable_channel($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_towels_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $towels = new multi_values();
               return $towels->get_chosen_room_towels($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_toilet_papers_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $toilet_papers = new multi_values();
               return $toilet_papers->get_chosen_room_toilet_papers($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_number_beds_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $number_beds = new multi_values();
               return $number_beds->get_chosen_room_number_beds($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_price_per_night_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $price_per_night = new multi_values();
               return $price_per_night->get_chosen_room_price_per_night($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_smocking_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $smocking = new multi_values();
               return $smocking->get_chosen_room_smocking($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_status_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $status = new multi_values();
               return $status->get_chosen_room_status($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_max_adults_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $max_adults = new multi_values();
               return $max_adults->get_chosen_room_max_adults($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_max_children_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'room') {               $id = $_SESSION['id_upd'];
               $max_children = new multi_values();
               return $max_children->get_chosen_room_max_children($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}


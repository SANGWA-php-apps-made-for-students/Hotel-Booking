<?php 
require_once 'connection.php';
class deletions{


 function deleteFrom_account( $account_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM account where account_id =:account_id");
$smt->bindValue(':account_id',$account_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_account_category( $account_category_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM account_category where account_category_id =:account_category_id");
$smt->bindValue(':account_category_id',$account_category_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_profile( $profile_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM profile where profile_id =:profile_id");
$smt->bindValue(':profile_id',$profile_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_image( $image_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM image where image_id =:image_id");
$smt->bindValue(':image_id',$image_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_room( $room_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM room where room_id =:room_id");
$smt->bindValue(':room_id',$room_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_guest( $guest_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM guest where guest_id =:guest_id");
$smt->bindValue(':guest_id',$guest_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_reservation( $reservation_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM reservation where reservation_id =:reservation_id");
$smt->bindValue(':reservation_id',$reservation_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_payment( $payment_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM payment where payment_id =:payment_id");
$smt->bindValue(':payment_id',$payment_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_checkout( $checkout_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM checkout where checkout_id =:checkout_id");
$smt->bindValue(':checkout_id',$checkout_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


}


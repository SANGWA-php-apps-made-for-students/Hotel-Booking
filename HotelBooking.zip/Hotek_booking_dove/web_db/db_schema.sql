
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account_category`     int(11)   
,`date_created`     Date 
, `profile`     int(11)   
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`is_online`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`dob`     Date 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`telephone_number`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`residence`     VARCHAR(60) 
, `image`     int(11)   

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 
, `room`     int(11)   

,PRIMARY KEY (`image_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `room`
--

CREATE TABLE IF NOT EXISTS `room` (
`room_id`     int(11) NOT NULL AUTO_INCREMENT 
,`floor_number`     VARCHAR(60) 
,`flat_tv`     VARCHAR(60) 
,`wifi`     VARCHAR(60) 
,`shower`     VARCHAR(60) 
,`heating`     VARCHAR(60) 
,`cable_channel`     VARCHAR(60) 
,`towels`     VARCHAR(60) 
,`toilet_papers`     VARCHAR(60) 
, `number_beds`     int(11)   
,`price_per_night`     VARCHAR(60) 
,`smocking`     VARCHAR(60) 
,`status`     VARCHAR(60) 
, `max_adults`     int(11)   
, `max_children`     int(11)   

,PRIMARY KEY (`room_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `guest`
--

CREATE TABLE IF NOT EXISTS `guest` (
`guest_id`     int(11) NOT NULL AUTO_INCREMENT 
, `profile`     int(11)   

,PRIMARY KEY (`guest_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `reservation`
--

CREATE TABLE IF NOT EXISTS `reservation` (
`reservation_id`     int(11) NOT NULL AUTO_INCREMENT 
, `guest`     int(11)   
,`start_date`     Date 
,`end_date`     Date 
, `room`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`reservation_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
`payment_id`     int(11) NOT NULL AUTO_INCREMENT 
, `reservation`     int(11)   
, `amount`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`payment_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `checkout`
--

CREATE TABLE IF NOT EXISTS `checkout` (
`checkout_id`     int(11) NOT NULL AUTO_INCREMENT 
, `reservation`     int(11)   
, `account`     int(11)   
, `charges_penalty`     int(11)   
,`comments`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`checkout_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


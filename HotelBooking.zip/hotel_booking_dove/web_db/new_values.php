<?php

class new_values {

    function new_account($account_category, $date_created, $profile, $username, $password, $is_online) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");
            $stm->execute(array(':account_id' => 0, ':account_category' => $account_category, ':date_created' => $date_created, ':profile' => $profile, ':username' => $username, ':password' => $password, ':is_online' => $is_online
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_account_category($name) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
            $stm->execute(array(':account_category_id' => 0, ':name' => $name
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_checkout($reservation, $account, $charges_penalty, $comments, $entry_date, $User) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into checkout values(:checkout_id, :reservation,  :account,  :charges_penalty,  :comments,  :entry_date,  :User)");
            $stm->execute(array(':checkout_id' => 0, ':reservation' => $reservation, ':account' => $account, ':charges_penalty' => $charges_penalty, ':comments' => $comments, ':entry_date' => $entry_date, ':User' => $User
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_guest() {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into guest values(:guest_id,)");
            $stm->execute(array(':guest_id' => 0,
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_image($path, $room) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into image values(:image_id, :path,  :room)");
            $stm->execute(array(':image_id' => 0, ':path' => $path, ':room' => $room
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_payment($reservation, $amount, $entry_date, $User) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into payment values(:payment_id, :reservation,  :amount,  :entry_date,  :User)");
            $stm->execute(array(':payment_id' => 0, ':reservation' => $reservation, ':amount' => $amount, ':entry_date' => $entry_date, ':User' => $User
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");
            $stm->execute(array(':profile_id' => 0, ':dob' => $dob, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender, ':telephone_number' => $telephone_number, ':email' => $email, ':residence' => $residence, ':image' => $image
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_reservation($guest, $start_date, $end_date, $room, $entry_date, $User) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into reservation values(:reservation_id, :guest,  :start_date,  :end_date,  :room,  :entry_date,  :User)");
            $stm->execute(array(':reservation_id' => 0, ':guest' => $guest, ':start_date' => $start_date, ':end_date' => $end_date, ':room' => $room, ':entry_date' => $entry_date, ':User' => $User
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_room($floor_number, $flat_tv, $wifi, $shower, $heating, $cable_channel, $towels, $toilet_papers, $number_beds, $price_per_night, $smocking, $status, $max_child, $max_adult) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into room values(:room_id, :floor_number,  :flat_tv,  :wifi,  :shower,  :heating,  :cable_channel,  :towels,  :toilet_papers,  :number_beds,  :price_per_night,  :smocking,  :status,  :max_child,  :max_adult)");
            $stm->execute(array(':room_id' => 0, ':floor_number' => $floor_number, ':flat_tv' => $flat_tv, ':wifi' => $wifi, ':shower' => $shower, ':heating' => $heating, ':cable_channel' => $cable_channel, ':towels' => $towels, ':toilet_papers' => $toilet_papers, ':number_beds' => $number_beds, ':price_per_night' => $price_per_night, ':smocking' => $smocking, ':status' => $status, ':max_child' => $max_child, ':max_adult' => $max_adult
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_checkin($date, $reservation) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into checkin values(:checkin_id, :date,  :reservation)");
            $stm->execute(array(':checkin_id' => 0, ':date' => $date, ':reservation' => $reservation
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

}

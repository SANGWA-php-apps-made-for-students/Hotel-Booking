<?php

require_once 'connection.php';

class updates {

    function update_account($account_category, $date_created, $profile, $username, $password, $is_online, $account_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
        $stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online, $account_id));
    }

    function update_account_category($name, $account_category_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
        $stmt->execute(array($name, $account_category_id));
    }

    function update_checkout($reservation, $account, $charges_penalty, $comments, $entry_date, $User, $checkout_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE checkout set 
reservation= ?, account= ?, charges_penalty= ?, comments= ?, entry_date= ?, User= ? WHERE checkout_id=?");
        $stmt->execute(array($reservation, $account, $charges_penalty, $comments, $entry_date, $User, $checkout_id));
    }


    function update_image($path, $room, $image_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE image set 
path= ?, room= ? WHERE image_id=?");
        $stmt->execute(array($path, $room, $image_id));
    }

    function update_payment($reservation, $amount, $entry_date, $User, $payment_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE payment set 
reservation= ?, amount= ?, entry_date= ?, User= ? WHERE payment_id=?");
        $stmt->execute(array($reservation, $amount, $entry_date, $User, $payment_id));
    }

    function update_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
        $stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id));
    }

    function update_reservation($guest, $start_date, $end_date, $room, $entry_date, $User, $reservation_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE reservation set 
guest= ?, start_date= ?, end_date= ?, room= ?, entry_date= ?, User= ? WHERE reservation_id=?");
        $stmt->execute(array($guest, $start_date, $end_date, $room, $entry_date, $User, $reservation_id));
    }

    function update_room($floor_number, $flat_tv, $wifi, $shower, $heating, $cable_channel, $towels, $toilet_papers, $number_beds, $price_per_night, $smocking, $status, $max_child, $max_adult, $room_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE room set 
floor_number= ?, flat_tv= ?, wifi= ?, shower= ?, heating= ?, cable_channel= ?, towels= ?, toilet_papers= ?, number_beds= ?, price_per_night= ?, smocking= ?, status= ?, max_child= ?, max_adult= ? WHERE room_id=?");
        $stmt->execute(array($floor_number, $flat_tv, $wifi, $shower, $heating, $cable_channel, $towels, $toilet_papers, $number_beds, $price_per_night, $smocking, $status, $max_child, $max_adult, $room_id));
    }

    function update_checkin($date, $reservation, $checkin_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE checkin set 
date= ?, reservation= ? WHERE checkin_id=?");
        $stmt->execute(array($date, $reservation, $checkin_id));
    }

}

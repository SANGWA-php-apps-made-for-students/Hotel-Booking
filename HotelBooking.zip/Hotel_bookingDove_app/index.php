<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 

        <link href="web_scripts/date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="web_scripts/date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="web_scripts/date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="web_scripts/date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="web_scripts/date_picker/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="web_scripts/date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>  

        <style>
            .personal_info_pane table td{
                padding: 5px;
            }

            .personal_info_pane table td .textbox{
                padding: 8px;
                width: 400px
            }
            .only_data{
                background-color: #db6fd8;
                width: 90%;
            }

        </style>
    </head>
    <body>
        <?php
        include 'header_menu.php';
        ?>
        <div id="fb-root"></div>
        <script>
//            (function (d, s, id) {
//                var js, fjs = d.getElementsByTagName(s)[0];
//                if (d.getElementById(id))
//                    return;
//                js = d.createElement(s);
//                js.id = id;
//                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
//                fjs.parentNode.insertBefore(js, fjs);
//            }(document, 'script', 'facebook-jssdk'));
        </script>        

        <div class="parts abs_full  off" style="overflow: hidden; position: fixed;">
            <div class="parts close_btn"></div>
        </div>
        <div class="parts eighty_centered x_height_5x data_res off" id="room_res">
            <div class="parts data_loadong_pic fifty_centered no_paddin_shade_no_Border">

            </div>
            <input type="hidden" class="textbox" required="true" id="room_id" name="name"   />

            <div class="parts ninety_centered no_paddin_shade_no_Border margin_free  off only_data" style="  z-index: 90; ">

            </div> 
            <div class="parts eighty_centered x_height_4x no_paddin_shade_no_Border   personal_info_pane off">
                <table class="new_data_table full_center_two_h heit_free">
                    <tr>
                        <td colspan="2">
                            <div class="xx_titles whilte_text" id="title">
                                Provide your personal information</div></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td><input type="text" class="textbox" required="true" name="name"   /></td>
                    </tr>
                    <tr>
                        <td>Last name</td>
                        <td><input type="text" class="textbox" required="true" id="txt_last_name" name="txt_last_name"   /></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td><input type="text" class="textbox" required="true" id="txt_email"   name="txt_email"   /></td>
                    </tr>
                    <tr>

                        <td colspan="2" ><button class="btn_personal_info ">Book now</button>   </td>
                    </tr>
                </table>

            </div>
            <div class="parts no_shade_noBorder xxx_titles done_pane whilte_text off">Reservation done successfully<br/>
            You will use your email as your username and 123 as your password.
            </div>
        </div>

        <div class="parts eighty_centered x_height_4x no_shade_noBorder contents" style="height: 450px;">
            <div class="ninety_centered heit_free d_picker_holder">
                <div class=" "><input type="text"  id="txt_checkin" class="textbox full_center_two_h heit_free" autocomplete="off"  placeholder="Pick Check in dates" name="txt_name"   /></div>
                <div class=" "><input type="text"  id="txt_checkout" class="textbox full_center_two_h heit_free" autocomplete="off" placeholder="Pick Check out dates" name="txt_name"   /></div>
                <div class=" heit_free">
                    <select id="cbo_adults">
                        <option value="0">-Adults-</option>
                        <option value="1">1 adult</option>
                        <option value="2">2 adults</option>
                        <option value="3">3 adults</option>
                        <option value="4">4 adults</option>
                        <option value="5">5 adults</option>
                    </select>
                </div>
                <div class=" heit_free"> 
                    <select id="cbo_children">
                        <option value="0">-Children-</option>
                        <option value="1">1 Child</option>
                        <option value="2">2 Children</option>
                        <option value="3">3 Children</option>
                        <option value="4">4 Children</option>
                        <option value="5">5 Children</option>
                    </select>
                </div>
                <div class=" heit_free"><button class="full_center_two_h heit_free room_search_btn">Search</button></div>
            </div>
        </div>
        <div class="parts other_news full_center_two_h heit_free">
            <div class="parts x_titles no_shade_noBorder eighty_centered">
                Featured
            </div>
            <div class="parts  no_paddin_shade_no_Border eighty_centered heit_free img_holder">
                <img class="parts" id="" src="" width="300px" height="300px"/>
                <img class="parts" id="" src="" width="300px" height="300px"/>
                <img class="parts" id="" src="" width="300px" height="300px"/>
                <img class="parts" id="" src="" width="300px" height="300px"/>
            </div>
        </div>
        <div class="parts eighty_centered footer off">
            Copyrights <?php echo date("Y"); ?>
        </div>    
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="web_scripts/date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="web_scripts/date_picker/jquery-ui.min.js" type="text/javascript"></script>

        <script>
            $('#txt_checkin,  #txt_checkout').datepicker({
                dateFormat: 'yy-mm-dd'
            });
        </script>
    </body>
</html>

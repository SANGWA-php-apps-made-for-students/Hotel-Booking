<?php

session_start();

if (isset($_POST['cbo_account_category'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
    return $id;
}
if (isset($_POST['cbo_profile'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
    return $id;
}
if (isset($_POST['cbo_image'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_image_id_by_image_name($_POST['cbo_image']);
    return $id;
}
if (isset($_POST['cbo_room'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_room_id_by_room_name($_POST['cbo_room']);
    return $id;
}
if (isset($_POST['cbo_guest'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_guest_id_by_guest_name($_POST['cbo_guest']);
    return $id;
}
if (isset($_POST['cbo_room'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_room_id_by_room_name($_POST['cbo_room']);
    return $id;
}
if (isset($_POST['cbo_reservation'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_reservation_id_by_reservation_name($_POST['cbo_reservation']);
    return $id;
}
if (isset($_POST['cbo_reservation'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_reservation_id_by_reservation_name($_POST['cbo_reservation']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}

if (isset($_POST['table_to_update'])) {
    $id_upd = $_POST['id_update'];
    $table_upd = $_POST['table_to_update'];
    $pref = 'upd_';
    $sufx = $table_upd;
    $_SESSION['table_to_update'] = $table_upd;
    $_SESSION['id_upd'] = $id_upd;
    echo $_SESSION['id_upd'];
}


//The Delete from account
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account($id);
}
//The Delete from account_category
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account_category') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account_category($id);
}
//The Delete from profile
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'profile') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_profile($id);
}
//The Delete from image
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'image') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_image($id);
}
//The Delete from room
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'room') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_room($id);
}
//The Delete from guest
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'guest') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_guest($id);
}
//The Delete from reservation
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'reservation') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_reservation($id);
}
//The Delete from payment
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'payment') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_payment($id);
}
//The Delete from checkout
if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'checkout') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_checkout($id);
}
if (isset($_POST['pagination_n'])) {
    $_SESSION['pagination_n'] = $_POST['pagination_n'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['paginated_page'];
}
if (isset($_POST['page_no_iteml'])) {
    unset($_SESSION['pagination_n']);
    $_SESSION['page_no_iteml'] = $_POST['page_no_iteml'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['page_no_iteml'];
}


// <editor-fold defaultstate="collapsed" desc="---Addon ----">
if (filter_has_var(INPUT_POST, 'reservation_by_date')) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $checkin = filter_input(INPUT_POST, 'checkin');
    $checkout = filter_input(INPUT_POST, 'checkout');
    $adults = filter_input(INPUT_POST, 'adults');
    $children = filter_input(INPUT_POST, 'children');
    echo $obj->list_reservation_by_checkin($adults, $children);
}
if (filter_has_var(INPUT_POST, 'make_reservation')) {
    require_once '../web_db/new_values.php';
    require_once '../web_db/multi_values.php';
    require_once '../web_db/updates.php';
    $obj = new new_values();
    $m = new multi_values();
    $upd = new updates();
    $checkin = filter_input(INPUT_POST, 'checkin');
    $checkout = filter_input(INPUT_POST, 'checkout');
    $roomid = filter_input(INPUT_POST, 'roomid');
    $email = filter_input(INPUT_POST, 'email');
    $name = filter_input(INPUT_POST, 'name');
    $last_name = filter_input(INPUT_POST, 'last_name');
    $obj->new_profile(date('h:m:d'), $name, $last_name, 'Not known', '', $email, '', 0);
    $last_profile = $m->get_last_profile();
    $obj->new_account(11, date('h:m:d'), $last_profile, $email, 123, 'No');
    $last_acc = $m->get_last_account();
    $obj->new_reservation($last_acc, $checkin, $checkout, $roomid, date('h:m:d'), $last_acc);
    $upd->update_room_status('not available', $roomid);
    
}
if (filter_has_var(INPUT_POST, 'home_data')) {
    require_once '../web_db/multi_values.php';
    $obj= new multi_values();
    $min=3;
    echo $obj->list_room($min);
}

if (filter_has_var(INPUT_POST, 'get_price_by_reservation')) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $get_price_by_reservation = filter_input(INPUT_POST, 'get_price_by_reservation');
    echo $obj->get_price_by_reservation($get_price_by_reservation);
}
// </editor-fold>

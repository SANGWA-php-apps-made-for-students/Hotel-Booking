<?php session_start();?><!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Admin dashboard</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
            require_once './admin_header.php';
        ?>
        <div class="parts no_paddin_shade_no_Border eighty_centered">
              <div class="parts xx_titles top_off_xx">
                  <?php echo 'Welcome '.$_SESSION['names'] .'  ('.$_SESSION['cat'].')' ?>
             
        </div>
            <div class="parts no_shade_noBorder push_right">
                
            </div>
        </div>
      
    </body>
</html>

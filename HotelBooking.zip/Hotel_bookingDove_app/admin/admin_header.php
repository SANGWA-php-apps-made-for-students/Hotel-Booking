<style>
    .menu a{
        color: #fff;
    }    
</style>
<div class="parts  full_center_two_h heit_free margin_free no_paddin_shade_no_Border"style="background-color: #000080;">   
    <div class="parts  eighty_centered heit_free margin_free no_shade_noBorder" style="font-size: 30px;color: #fff;">  Dove Hotel  </div>
    <div class="parts menu eighty_centered heit_free margin_free no_shade_noBorder">  
        <a href="admin_dashboard.php"class="menu_link">Dashboard</a>
        <?php
        if (isset($_SESSION['cat'])) {
            if ($_SESSION['cat'] == 'admin') {
                admin_menu();
            }
            if ($_SESSION['cat'] == 'manager') {
                manager_menu();
            }
            if ($_SESSION['cat'] == 'Receptionist') {
                receptionist();
            }
            if ($_SESSION['cat'] == 'guest') {
                guest_menu();
            }
        }
        ?>
        <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
            <a href="../logout.php" class="menu_link"><?php echo '('.$_SESSION['cat'].') '; ?>Logout</a>
        </div>
    </div>
</div>     




<?php

function admin_menu() {
    ?>  <a href="new_account.php"class="menu_link">Users</a>    
    <?php
}

function manager_menu() {
    ?>  <a href="new_room.php"class="menu_link">room</a>
    <a href="new_reservation.php"class="menu_link">reservation</a>
    <a href="new_checkin.php"class="menu_link">Checkin</a>
    <a href="new_payment.php"class="menu_link">payment</a>
    <a href="new_checkout.php"class="menu_link">checkout</a>    
    <?php
}

function guest_menu() {
    ?>   
    
    <a href="new_reservation.php"class="menu_link">My reservations</a>
    <a href="new_payment.php"class="menu_link">My payments</a>  
    <?php
}

function receptionist() {
    ?>
     <a href="new_room.php"class="menu_link">room</a>
    <a href="new_checkin.php"class="menu_link">Checkin</a>
    <a href="new_payment.php"class="menu_link">payment</a>
    <a href="new_checkout.php"class="menu_link">checkout</a>  
    <?php
}

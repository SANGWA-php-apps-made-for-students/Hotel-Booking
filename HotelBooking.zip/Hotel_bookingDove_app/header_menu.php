<style>
    .menu a{
        color: #fff;
    }    
</style>
<div class="parts  full_center_two_h heit_free margin_free no_paddin_shade_no_Border"style="background-color: #103670;">   
    <div class="parts  eighty_centered heit_free margin_free margin_free no_paddin_shade_no_Border"> 
        <div class="parts x_width_4h no_shade_noBorder    no_paddin_shade_no_Border"style="color: #fff;font-size: 30px;padding-left: 30px;">
            Dove Hotel         
        </div>
        <div class="parts two_fifty_right heit_free  no_shade_noBorder " style="padding-top:9px;">
            <a href="login.php" class="menu_link">Register</a>
            <a href="login.php" class="menu_link">Login</a>
        </div>
    </div>
    <div class="parts menu eighty_centered heit_free margin_free no_shade_noBorder">  
        <a href="index.php  " class="menu_link">Home</a>
        <a href="#" class="menu_link">Featured</a>
        <a href="#" class="menu_link">Talk to agent</a>
        <a href="#"class="menu_link">About us</a>
    </div>
</div>     


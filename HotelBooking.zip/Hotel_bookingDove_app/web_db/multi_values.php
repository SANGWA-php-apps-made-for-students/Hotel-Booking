<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_account($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account "
                . " join account_category on account.account_category=account_category.account_category_id";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account </td>
                    <td> Category </td><td> Date </td><td>Username  </td><td> Password </td> 
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_id']; ?>
                    </td>
                    <td class="account_category_id_cols account " title="account" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>  <?php echo $this->_e($row['date_created']); ?>  </td>   
                    
                    <td>  <?php  echo $this->_e($row['username']); ?> </td>
                    <td>   <?php echo $this->_e($row['password']); ?> </td>
                    <td> 
                        <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="account_id"  data-table="
                           <?php echo $row['account_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_update_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_account_category($id) {
            
            $db = new dbconnection();
            $sql = "select   account.account_category from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account_category'];
            echo $field;
        }

        function get_chosen_account_date_created($id) {
            $db = new dbconnection();
            $sql = "select   account.date_created from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date_created'];
            echo $field;
        }

        function get_chosen_account_profile($id) {

            $db = new dbconnection();
            $sql = "select   account.profile from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['profile'];
            echo $field;
        }

        function get_chosen_account_username($id) {

            $db = new dbconnection();
            $sql = "select   account.username from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['username'];
            echo $field;
        }

        function get_chosen_account_password($id) {

            $db = new dbconnection();
            $sql = "select   account.password from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['password'];
            echo $field;
        }

        function get_chosen_account_is_online($id) {

            $db = new dbconnection();
            $sql = "select   account.is_online from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['is_online'];
            echo $field;
        }

        function All_account() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_id   from account";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function get_last_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function list_account_category($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account_category";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account_category </td>
                    <td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_category_id']; ?>
                    </td>
                    <td class="name_id_cols account_category " title="account_category" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="account_category_id"  data-table="
                           <?php echo $row['account_category_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_category_update_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_category_name($id) {

            $db = new dbconnection();
            $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_category_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_account_category() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_category_id   from account_category";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function get_last_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function list_profile($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from profile";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> profile </td>
                    <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['profile_id']; ?>
                    </td>
                    <td class="dob_id_cols profile " title="profile" >
                        <?php echo $this->_e($row['dob']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['gender']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['telephone_number']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['email']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['residence']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['image']); ?>
                    </td>


                    <td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="profile_id"  data-table="
                           <?php echo $row['profile_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="profile_update_link" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_profile_dob($id) {

            $db = new dbconnection();
            $sql = "select   profile.dob from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['dob'];
            echo $field;
        }

        function get_chosen_profile_name($id) {

            $db = new dbconnection();
            $sql = "select   profile.name from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_profile_last_name($id) {

            $db = new dbconnection();
            $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['last_name'];
            echo $field;
        }

        function get_chosen_profile_gender($id) {

            $db = new dbconnection();
            $sql = "select   profile.gender from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['gender'];
            echo $field;
        }

        function get_chosen_profile_telephone_number($id) {

            $db = new dbconnection();
            $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['telephone_number'];
            echo $field;
        }

        function get_chosen_profile_email($id) {

            $db = new dbconnection();
            $sql = "select   profile.email from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['email'];
            echo $field;
        }

        function get_chosen_profile_residence($id) {

            $db = new dbconnection();
            $sql = "select   profile.residence from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['residence'];
            echo $field;
        }

        function get_chosen_profile_image($id) {

            $db = new dbconnection();
            $sql = "select   profile.image from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['image'];
            echo $field;
        }

        function All_profile() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  profile_id   from profile";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function get_last_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function list_image($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from image";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> image </td>
                    <td>  </td><td> Room </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['image_id']; ?>
                    </td>
                    <td class="path_id_cols image " title="image" >
                        <?php echo $this->_e($row['path']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['room']); ?>
                    </td>


                    <td>
                        <a href="#" class="image_delete_link" style="color: #000080;" data-id_delete="image_id"  data-table="
                           <?php echo $row['image_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="image_update_link" style="color: #000080;" value="
                           <?php echo $row['image_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_image_path($id) {

            $db = new dbconnection();
            $sql = "select   image.path from image where image_id=:image_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':image_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['path'];
            echo $field;
        }

        function get_chosen_image_room($id) {

            $db = new dbconnection();
            $sql = "select   image.room from image where image_id=:image_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':image_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['room'];
            echo $field;
        }

        function All_image() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  image_id   from image";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_image() {
            $con = new dbconnection();
            $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['image_id'];
            return $first_rec;
        }

        function get_last_image() {
            $con = new dbconnection();
            $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['image_id'];
            return $first_rec;
        }

        function get_image_by_room($room) {
            $db = new dbconnection();
            $sql = "select room.room_id, image.path from room join image
                on room.room_id=image.room
                where room.room_id=:room_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->execute(array(":room_id" => $room));
            if ($stmt->rowCount() > 0) {
                while ($row = $stmt->fetch()) {
                    echo '<div class="parts no_paddin_shade_no_Border imageThumb full_center_two_h heit_free"><img class="parts" id=""   src="../web_images/rooms/' . $row['path'] . '"     width="300px" height="300px"/></div>';
                }
            }
        }

        function list_room($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from room "
                    . " join image on room.room_id=image.room"
                    . " where status='available' group by room.room_id";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>

        <?php
        $pages = 1;
        while ($row = $stmt->fetch()) {
            $this->get_image_by_room($row['room_id']);
            ?>  

            <div class="parts no_shade_noBorder"  style="border: 1px solid #006dff;">
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['flat_tv'] == 'yes') ? 'checked' : ''; ?>   id="flat_tv"  value="flat_tv"><label for="flat_tv" >Flat TV   </label> </div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo $this->get_checked($row['wifi']); ?>            id="wifi"  value="wifi" />  <label for="wifi" >WiFI </label> </div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo $this->get_checked($row['shower']); ?>          id="shower"  value="shower"><label for="shower" > Shower </label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['heating'] == 'yes') ? 'checked' : ''; ?>  id="heating"  value="heating"><label for="heating" > Heating </label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['cable_channel'] == 'yes') ? 'checked' : ''; ?>id="cable_channel" value="cable_channel"> <label for="cable_channel" > Cable Channel</label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['towels'] == 'yes') ? 'checked' : ''; ?> id="towels"  value="towels"> <label for="towels" > Towels</label> </div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['toilet_papers'] == 'yes') ? 'checked' : ''; ?> id="toilet_p"  value="toilet_p"> <label for="toilet_p" > Toilet Papers </label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['number_beds'] == 'yes') ? 'checked' : ''; ?> id="number_beds"  value="number_beds">  <label for="number_beds" > Number beds</label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['price_per_night'] == 'yes') ? 'checked' : ''; ?>id="price_per_night" value="price_per_night"> <label for="price_per_night" > Price/Night </label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['smocking'] == 'yes') ? 'checked' : ''; ?> id="smoking"  value="smoking">  <label for="smoking" > Smoking</label></div>
                <div class="parts no_shade_noBorder chk_data"> Status: <?php echo $row['status'] ?> </div>
                <div class="parts no_shade_noBorder chk_data">Max children: <?php echo $row['max_child'] ?>    </div>
                <div class="parts no_shade_noBorder chk_data"> Max Adult:  <?php echo $row['max_adult'] ?>      </div>

                <div class="parts full_center_two_h heit_free no_shade_noBorder del_btns">
                    <a href="#" class="room_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['room_id']; ?>"  data-table="room">Delete</a>
                    <a href="#" class="room_update_link" style="color: #000080;" data-id_update="<?php echo $row['room_id']; ?>" data-table="room" >Update</a>
                </div>
            </div>
            <!--            <tr class="off"> 

                <td>
            <?php echo $row['room_id']; ?>
                </td>
                <td class="floor_number_id_cols room " title="room" >   <?php echo $this->_e($row['floor_number']); ?>    </td>


                <td>
                    <a href="#" class="room_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['room_id']; ?>"  data-table="room">Delete</a>
                </td>
                <td>
                    <a href="#" class="room_update_link" style="color: #000080;" data-id_update="<?php echo $row['room_id']; ?>" data-table="room" >Update</a>
                </td>
            </tr>-->
            <?php
            $pages += 1;
        }
        ?> 
        <?php
    }

    function list_room_not_av($min) {
        try {
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "select * from room where status='not available'";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));

            $pages = 1;
            while ($row = $stmt->fetch()) {
                $this->get_image_by_room($row['room_id']);
                ?>
                <div class="parts no_shade_noBorder"  style="border: 1px solid #006dff;">
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['flat_tv'] == 'yes') ? 'checked' : ''; ?>id="flat_tv"  value="flat_tv"><label for="flat_tv" >Flat TV   </label> </div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo $this->get_checked($row['wifi']); ?>            id="wifi"  value="wifi" />  <label for="wifi" >WiFI </label> </div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo $this->get_checked($row['shower']); ?>          id="shower"  value="shower"><label for="shower" > Shower </label></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['heating'] == 'yes') ? 'checked' : ''; ?>  id="heating"  value="heating"><label for="heating" > Heating </label></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['cable_channel'] == 'yes') ? 'checked' : ''; ?>id="cable_channel" value="cable_channel"> <label for="cable_channel" > Cable Channel</label></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['towels'] == 'yes') ? 'checked' : ''; ?> id="towels"  value="towels"> <label for="towels" > Towels</label> </div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['toilet_papers'] == 'yes') ? 'checked' : ''; ?> id="toilet_p"  value="toilet_p"> <label for="toilet_p" > Toilet Papers </label></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['number_beds'] == 'yes') ? 'checked' : ''; ?> id="number_beds"  value="number_beds">  <label for="number_beds" > Number beds</label></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['price_per_night'] == 'yes') ? 'checked' : ''; ?>id="price_per_night" value="price_per_night"> <label for="price_per_night" > Price/Night </label></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['smocking'] == 'yes') ? 'checked' : ''; ?> id="smoking"  value="smoking">  <label for="smoking" > Smoking</label></div>
                    <div class="parts no_shade_noBorder chk_data"> Status: <?php echo $row['status'] ?> </div>
                    <div class="parts no_shade_noBorder chk_data">Max children: <?php echo $row['max_child'] ?>    </div>
                    <div class="parts no_shade_noBorder chk_data"> Max Adult:  <?php echo $row['max_adult'] ?>      </div>
                </div>

                <?php
                $pages += 1;
            }
            ?> 
            <?php
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function get_checked($val) {
        return ($val == 'yes') ? 'checked' : '';
    }

//chosen individual field
    function get_chosen_room_floor_number($id) {

        $db = new dbconnection();
        $sql = "select   room.floor_number from room where room_id=:room_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':room_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['floor_number'];
        echo $field;
    }

    function get_chosen_room_flat_tv($id) {

        $db = new dbconnection();
        $sql = "select   room.flat_tv from room where room_id=:room_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':room_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['flat_tv'];
        echo $field;
    }

    function get_chosen_room_wifi($id) {

        $db = new dbconnection();
        $sql = "select   room.wifi from room where room_id=:room_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':room_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['wifi'];
        echo $field;
    }

    function get_chosen_room_shower($id) {

        $db = new dbconnection();
        $sql = "select   room.shower from room where room_id=:room_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':room_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['shower'];
        echo $field;
    }

    function get_chosen_room_heating($id) {

        $db = new dbconnection();
        $sql = "select   room.heating from room where room_id=:room_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':room_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['heating'];
        echo $field;
    }

    function get_chosen_room_cable_channel($id) {

        $db = new dbconnection();
        $sql = "select   room.cable_channel from room where room_id=:room_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':room_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['cable_channel'];
        echo $field;
    }

    function get_chosen_room_towels($id) {

        $db = new dbconnection();
        $sql = "select   room.towels from room where room_id=:room_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':room_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['towels'];
        echo $field;
    }

    function get_chosen_room_toilet_papers($id) {

        $db = new dbconnection();
        $sql = "select   room.toilet_papers from room where room_id=:room_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':room_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['toilet_papers'];
        echo $field;
    }

    function get_chosen_room_number_beds($id) {

        $db = new dbconnection();
        $sql = "select   room.number_beds from room where room_id=:room_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':room_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['number_beds'];
        echo $field;
    }

    function get_chosen_room_price_per_night($id) {

        $db = new dbconnection();
        $sql = "select   room.price_per_night from room where room_id=:room_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':room_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['price_per_night'];
        echo $field;
    }

    function get_chosen_room_smocking($id) {

        $db = new dbconnection();
        $sql = "select   room.smocking from room where room_id=:room_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':room_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['smocking'];
        echo $field;
    }

    function get_chosen_room_max_adults($id) {

        $db = new dbconnection();
        $sql = "select   room.max_adults from room where room_id=:room_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':room_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['max_adults'];
        echo $field;
    }

    function get_chosen_room_max_children($id) {

        $db = new dbconnection();
        $sql = "select   room.max_children from room where room_id=:room_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':room_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['max_children'];
        echo $field;
    }

    function All_room() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  room_id   from room";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function get_first_room() {
        $con = new dbconnection();
        $sql = "select room.room_id from room
                    order by room.room_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['room_id'];
        return $first_rec;
    }

    function get_last_room() {
        $con = new dbconnection();
        $sql = "select room.room_id from room
                    order by room.room_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['room_id'];
        return $first_rec;
    }

    function list_guest($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from guest";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> guest </td>

                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['guest_id']; ?>
                    </td>


                    <td>
                        <a href="#" class="guest_delete_link" style="color: #000080;" data-id_delete="guest_id"  data-table="
                           <?php echo $row['guest_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="guest_update_link" style="color: #000080;" value="
                           <?php echo $row['guest_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field

        function All_guest() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  guest_id   from guest";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_guest() {
            $con = new dbconnection();
            $sql = "select guest.guest_id from guest
                    order by guest.guest_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['guest_id'];
            return $first_rec;
        }

        function get_last_guest() {
            $con = new dbconnection();
            $sql = "select guest.guest_id from guest
                    order by guest.guest_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['guest_id'];
            return $first_rec;
        }

        function list_reservation($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            if ($_SESSION['cat'] == 'admin' | $_SESSION['cat'] == 'manager') {
                $sql = "select * from reservation  "
                        . " join account on account.account_id=reservation.guest
                            join account_category on account_category.account_category_id=account.account_category
                            join profile on profile.profile_id=account.profile
                            join room on room.room_id=reservation.room";
            } else {
                $sql = "select * from reservation "
                        . " join account on account.account_id=reservation.guest
                                join account_category on account_category.account_category_id=account.account_category
                                join profile on profile.profile_id=account.profile
                                join room on room.room_id=reservation.room "
                        . "where reservation.guest=" . $_SESSION['userid'];
            }
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> reservation </td>
                    <td> name </td><td>Last name</td><td> Start Date </td>
                    <td> End Date </td>
                    <td> Room </td><td> Entry Date </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['reservation_id']; ?>
                    </td>
                    <td class="guest_id_cols reservation " title="reservation" >  <?php echo $this->_e($row['name']); ?>   </td>
                    <td class="guest_id_cols reservation " title="reservation" >  <?php echo $this->_e($row['last_name']); ?>   </td>
                    <td>
                        <?php echo $this->_e($row['start_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['end_date']); ?>
                    </td>
                    <td>
                        <?php echo 'Room ';echo $this->_e($row['room']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <a href="#" class="reservation_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['reservation_id'];?>"  data-table="reservation">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="reservation_update_link" style="color: #000080;" value="
                           <?php echo $row['reservation_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_reservation_guest($id) {

            $db = new dbconnection();
            $sql = "select   reservation.guest from reservation where reservation_id=:reservation_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':reservation_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['guest'];
            echo $field;
        }

        function get_chosen_reservation_start_date($id) {

            $db = new dbconnection();
            $sql = "select   reservation.start_date from reservation where reservation_id=:reservation_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':reservation_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['start_date'];
            echo $field;
        }

        function get_chosen_reservation_end_date($id) {

            $db = new dbconnection();
            $sql = "select   reservation.end_date from reservation where reservation_id=:reservation_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':reservation_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['end_date'];
            echo $field;
        }

        function get_chosen_reservation_room($id) {

            $db = new dbconnection();
            $sql = "select   reservation.room from reservation where reservation_id=:reservation_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':reservation_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['room'];
            echo $field;
        }

        function get_chosen_reservation_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   reservation.entry_date from reservation where reservation_id=:reservation_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':reservation_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_reservation_User($id) {

            $db = new dbconnection();
            $sql = "select   reservation.User from reservation where reservation_id=:reservation_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':reservation_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function All_reservation() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  reservation_id   from reservation";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_reservation() {
            $con = new dbconnection();
            $sql = "select reservation.reservation_id from reservation
                    order by reservation.reservation_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['reservation_id'];
            return $first_rec;
        }

        function get_last_reservation() {
            $con = new dbconnection();
            $sql = "select reservation.reservation_id from reservation
                    order by reservation.reservation_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['reservation_id'];
            return $first_rec;
        }

        function list_payment($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            if ($_SESSION['cat'] == 'admin') {
                $sql = "select * from payment "
                        . " join reservation on reservation.reservation_id=payment.reservation "
                        . " join account on account.account_id=reservation.guest
                                join account_category on account_category.account_category_id=account.account_category
                                join profile on profile.profile_id=account.profile
                                join room on room.room_id=reservation.room ";
            } else {
                $sql = "select * from payment  "
                        . " join reservation on reservation.reservation_id=payment.reservation "
                        . " join account on account.account_id=reservation.guest
                                join account_category on account_category.account_category_id=account.account_category
                                join profile on profile.profile_id=account.profile
                                join room on room.room_id=reservation.room "                
                        . " where payment.User = " . $_SESSION['userid'];
            }
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> payment </td>
                    <td> Guest </td><td> Amount </td><td> Entry Date </td><td> User </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['payment_id']; ?>
                    </td>
                   <td class="guest_id_cols reservation " title="reservation" >  <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>   </td>
                    <td>
                        <?php echo $this->_e($row['amount']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['User']); ?>
                    </td>


                    <td>
                        <a href="#" class="payment_delete_link" style="color: #000080;" data-id_delete="payment_id"  data-table="
                <?php echo $row['payment_id'];
                ?>">Delete</a>
            </td>
            <td>
                <a href="#" class="payment_update_link" style="color: #000080;" value="
            <?php echo $row['payment_id']; ?>">Update</a>
            </td></tr>
            <?php
            $pages += 1;
        }
        ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_payment_reservation($id) {

        $db = new dbconnection();
        $sql = "select   payment.reservation from payment where payment_id=:payment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':payment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['reservation'];
        echo $field;
    }

    function get_chosen_payment_amount($id) {

        $db = new dbconnection();
        $sql = "select   payment.amount from payment where payment_id=:payment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':payment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['amount'];
        echo $field;
    }

    function get_chosen_payment_entry_date($id) {

        $db = new dbconnection();
        $sql = "select   payment.entry_date from payment where payment_id=:payment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':payment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    }

    function get_chosen_payment_User($id) {

        $db = new dbconnection();
        $sql = "select   payment.User from payment where payment_id=:payment_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':payment_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    }

    function All_payment() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  payment_id   from payment";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function get_first_payment() {
        $con = new dbconnection();
        $sql = "select payment.payment_id from payment
                    order by payment.payment_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['payment_id'];
        return $first_rec;
    }

    function get_last_payment() {
        $con = new dbconnection();
        $sql = "select payment.payment_id from payment
                    order by payment.payment_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['payment_id'];
        return $first_rec;
    }

    function list_checkout($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from checkout "
                . "join reservation on reservation.reservation_id=checkout.reservation "
                . " join account on account.account_id=reservation.guest
                                join account_category on account_category.account_category_id=account.account_category
                                join profile on profile.profile_id=account.profile
                                join room on room.room_id=reservation.room ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> checkout </td>

                    <td> Guest </td> <td> Charges of Penalty </td><td> Comments </td><td> Entry Date </td> 
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
            <?php echo $row['checkout_id']; ?>
                    </td>
                    <td class="guest_id_cols reservation " title="reservation" >  <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>   </td>

                    <td>
                        <?php echo $this->_e($row['charges_penalty']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['comments']); ?>
                    </td>
                    <td>
            <?php echo $this->_e($row['entry_date']); ?>
                    </td>

                    <td>
                        <a href="#" class="checkout_delete_link" style="color: #000080;" data-id_delete="checkout_id"  data-table="
            <?php echo $row['checkout_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="checkout_update_link" style="color: #000080;" value="
                <?php echo $row['checkout_id']; ?>">Update</a>
                    </td></tr>
                <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_checkout_reservation($id) {

            $db = new dbconnection();
            $sql = "select   checkout.reservation from checkout where checkout_id=:checkout_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':checkout_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['reservation'];
            echo $field;
        }

        function get_chosen_checkout_account($id) {

            $db = new dbconnection();
            $sql = "select   checkout.account from checkout where checkout_id=:checkout_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':checkout_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function get_chosen_checkout_charges_penalty($id) {

            $db = new dbconnection();
            $sql = "select   checkout.charges_penalty from checkout where checkout_id=:checkout_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':checkout_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['charges_penalty'];
            echo $field;
        }

        function get_chosen_checkout_comments($id) {

            $db = new dbconnection();
            $sql = "select   checkout.comments from checkout where checkout_id=:checkout_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':checkout_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['comments'];
            echo $field;
        }

        function get_chosen_checkout_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   checkout.entry_date from checkout where checkout_id=:checkout_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':checkout_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_checkout_User($id) {

            $db = new dbconnection();
            $sql = "select   checkout.User from checkout where checkout_id=:checkout_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':checkout_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function All_checkout() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  checkout_id   from checkout";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_checkout() {
            $con = new dbconnection();
            $sql = "select checkout.checkout_id from checkout
                    order by checkout.checkout_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['checkout_id'];
            return $first_rec;
        }

        function get_last_checkout() {
            $con = new dbconnection();
            $sql = "select checkout.checkout_id from checkout
                    order by checkout.checkout_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['checkout_id'];
            return $first_rec;
        }

        function get_account_category_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select account_category.account_category_id,   account_category.name from account_category";
            ?>
        <select class="textbox cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_image_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_room_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select room.room_id    from room";
        ?>
        <select class="textbox cbo_room"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['room_id'] . ">Room-" . $row['room_id'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_guest_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select guest.guest_id from guest";
        ?>
        <select class="textbox cbo_guest"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['guest_id'] . ">" . $row['guest_id'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_reservation_in_combo() {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "select reservation.reservation_id, 
                 reservation.reservation_id, reservation.entry_date,
                profile.name, profile.last_name 
                 from reservation 
                 join account on account.account_id=reservation.guest
                        join account_category on account_category.account_category_id=account.account_category
                        join profile on profile.profile_id=account.profile
                 where reservation.reservation_id not in (select reservation from payment)";
            ?>
            <select class="textbox cbo_reservation"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['reservation_id'] . ">" . $row['reservation_id'] . " - " . $row['name'] . "  " . $row['last_name'] . " - " . $row['entry_date'] . " </option>";
                }
                ?>
            </select>
            <?php
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function get_new_reservation_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select reservation.reservation_id, "
                . "  reservation.reservation_id, reservation.entry_date,"
                . " profile.name, profile.last_name "
                . " from reservation "
                . " join account on account.account_id=reservation.guest
                        join account_category on account_category.account_category_id=account.account_category
                        join profile on profile.profile_id=account.profile"
                . " where reservation.reservation_id not in (select reservation from checkin)";
        ?>
        <select class="textbox cbo_reservation"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['reservation_id'] . ">" . $row['reservation_id'] . "- " . $row['name'] . "  " . $row['last_name'] . " - " . $row['entry_date'] . "</option>";
            }
            ?>
        </select>
        <?php
    }

    function get_existing_reservation_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select reservation.reservation_id, 
                 reservation.reservation_id, reservation.entry_date,
                profile.name, profile.last_name 
                 from reservation 
                 join account on account.account_id=reservation.guest
                        join account_category on account_category.account_category_id=account.account_category
                        join profile on profile.profile_id=account.profile "
                . ""
                . "where reservation.reservation_id   in (select reservation from checkin)";
        ?>
        <select class="textbox cbo_reservation"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['reservation_id'] . ">" . $row['reservation_id'] . " - " . $row['name'] . "  " . $row['last_name'] . " - " . $row['entry_date'] . "</option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_user_username_by_user($username) {
        $con = new dbconnection();
        $sql = "select    username  from account   where  account.username =:username";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":username" => $username));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['username'];
        return $userid;
    }

    function list_checkin($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from checkin "
                . " join reservation on reservation.reservation_id=checkin.reservation "
                . " join account on account.account_id=reservation.guest
                                join account_category on account_category.account_category_id=account.account_category
                                join profile on profile.profile_id=account.profile
                                join room on room.room_id=reservation.room "
                . " ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> checkin </td>
                    <td> date </td>  <td> Guest </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['checkin_id']; ?>
                    </td>
                    <td class="date_id_cols checkin " title="checkin" >
            <?php echo $this->_e($row['date']); ?>
                    </td>
                    <td class="guest_id_cols reservation " title="reservation" >  <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>   </td>

                    <td>
                        <a href="#" class="checkin_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['checkin_id']; ?>"  data-table="checkin">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="checkin_update_link" style="color: #000080;" data-id_update="<?php echo $row['checkin_id']; ?>" data-table="checkin" >Update</a>
                    </td></tr>
                <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_checkin_date($id) {

            $db = new dbconnection();
            $sql = "select   checkin.date from checkin where checkin_id=:checkin_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':checkin_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date'];
            echo $field;
        }

        function get_chosen_checkin_reservation($id) {

            $db = new dbconnection();
            $sql = "select   checkin.reservation from checkin where checkin_id=:checkin_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':checkin_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['reservation'];
            echo $field;
        }

        function All_checkin() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  checkin_id   from checkin";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_checkin() {
            $con = new dbconnection();
            $sql = "select checkin.checkin_id from checkin
                    order by checkin.checkin_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['checkin_id'];
            return $first_rec;
        }

        function get_last_checkin() {
            $con = new dbconnection();
            $sql = "select checkin.checkin_id from checkin
                    order by checkin.checkin_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['checkin_id'];
            return $first_rec;
        }

        function get_room_by_reservation($reservation) {
            $con = new dbconnection();
            $sql = "select room from reservation
                join room on room.room_id=reservation.room
                where reservation.reservation_id=:reservation";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(':reservation' => $reservation));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['room'];
            return $first_rec;
        }

        function list_rooms($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from room where status='available'";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>

        <?php
        $pages = 1;
        while ($row = $stmt->fetch()) {
            ?>  <div class="parts no_shade_noBorder"  style="border: 1px solid #006dff;">
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['flat_tv'] == 'yes') ? 'checked' : ''; ?>   id="flat_tv"  value="flat_tv"><label for="flat_tv" >Flat TV   </label> </div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo $this->get_checked($row['wifi']); ?>            id="wifi"  value="wifi" />  <label for="wifi" >WiFI </label> </div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo $this->get_checked($row['shower']); ?>          id="shower"  value="shower"><label for="shower" > Shower </label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['heating'] == 'yes') ? 'checked' : ''; ?>  id="heating"  value="heating"><label for="heating" > Heating </label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['cable_channel'] == 'yes') ? 'checked' : ''; ?>id="cable_channel" value="cable_channel"> <label for="cable_channel" > Cable Channel</label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['towels'] == 'yes') ? 'checked' : ''; ?> id="towels"  value="towels"> <label for="towels" > Towels</label> </div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['toilet_papers'] == 'yes') ? 'checked' : ''; ?> id="toilet_p"  value="toilet_p"> <label for="toilet_p" > Toilet Papers </label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['number_beds'] == 'yes') ? 'checked' : ''; ?> id="number_beds"  value="number_beds">  <label for="number_beds" > Number beds</label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['price_per_night'] == 'yes') ? 'checked' : ''; ?>id="price_per_night" value="price_per_night"> <label for="price_per_night" > Price/Night </label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['smocking'] == 'yes') ? 'checked' : ''; ?> id="smoking"  value="smoking">  <label for="smoking" > Smoking</label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['status'] == 'yes') ? 'checked' : ''; ?> id="status"  value="status"> <label for="status" > Status</label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['max_child'] == 'yes') ? 'checked' : ''; ?> id="max_child"  value="max_child"> <label for="max_child" > Max Children</label></div>
                <div class="parts no_shade_noBorder chk_data"><input type="checkbox" name="feature" <?php echo ($row['max_adult'] == 'yes') ? 'checked' : ''; ?> id="max_adult"  value="max_adult"> <label for="max_adult" >  Max adult</label></div>
            </div>
            <tr class="off"> 

                <td>
            <?php echo $row['room_id']; ?>
                </td>
                <td class="floor_number_id_cols room " title="room" >   <?php echo $this->_e($row['floor_number']); ?>    </td>


                <td>
                    <a href="#" class="room_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['room_id']; ?>"  data-table="room">Delete</a>
                </td>
                <td>
                    <a href="#" class="room_update_link" style="color: #000080;" data-id_update="<?php echo $row['room_id']; ?>" data-table="room" >Update</a>
                </td>
            </tr>
            <?php
            $pages += 1;
        }
        ?> 
        <?php
    }

    function list_reservation_by_checkin($adult, $children) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from room "
                . " where  room.max_adult>=:adult and room.max_child>=:children "
                . " and room.status='available' ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":adult" => $adult, ":children" => $children));
        if ($stmt->rowCount() > 0) {
            while ($row = $stmt->fetch()) {
                ?> 
                <div class="parts no_shade_noBorder room_data_res"  style="border: 1px solid #006dff;">
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">Room <?php echo $row['room_id']; ?></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" disabled="true" name="feature" <?php echo ($row['flat_tv'] == 'yes') ? 'checked' : ''; ?>   id="flat_tv"  value="flat_tv"><label for="flat_tv" >Flat TV   </label> </div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" disabled="true" name="feature" <?php echo $this->get_checked($row['wifi']); ?>            id="wifi"  value="wifi" />  <label for="wifi" >WiFI </label> </div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" disabled="true" name="feature" <?php echo $this->get_checked($row['shower']); ?>          id="shower"  value="shower"><label for="shower" > Shower </label></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" disabled="true" name="feature" <?php echo ($row['heating'] == 'yes') ? 'checked' : ''; ?>  id="heating"  value="heating"><label for="heating" > Heating </label></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" disabled="true" name="feature" <?php echo ($row['cable_channel'] == 'yes') ? 'checked' : ''; ?>id="cable_channel" value="cable_channel"> <label for="cable_channel" > Cable Channel</label></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" disabled="true" name="feature" <?php echo ($row['towels'] == 'yes') ? 'checked' : ''; ?> id="towels"  value="towels"> <label for="towels" > Towels</label> </div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" disabled="true" name="feature" <?php echo ($row['toilet_papers'] == 'yes') ? 'checked' : ''; ?> id="toilet_p"  value="toilet_p"> <label for="toilet_p" > Toilet Papers </label></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" disabled="true" name="feature" <?php echo ($row['number_beds'] == 'yes') ? 'checked' : ''; ?> id="number_beds"  value="number_beds">  <label for="number_beds" > Number beds</label></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" disabled="true" name="feature" <?php echo ($row['price_per_night'] == 'yes') ? 'checked' : ''; ?>id="price_per_night" value="price_per_night"> <label for="price_per_night" > Price/Night </label></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" disabled="true" name="feature" <?php echo ($row['smocking'] == 'yes') ? 'checked' : ''; ?> id="smoking"  value="smoking">  <label for="smoking" > Smoking</label></div>
                    <div class="parts no_shade_noBorder chk_data"><input type="checkbox" disabled="true" name="feature" <?php echo ($row['status'] == 'yes') ? 'checked' : ''; ?> id="status"  value="status"> <label for="status" > Status</label></div>
                    <div class="parts no_shade_noBorder chk_data">
                        <?php echo 'Max children: ';echo $row['max_child'];?>
                    </div>
                    <div class="parts no_shade_noBorder chk_data">
                        <?php echo 'Max Adult: ';   echo $row['max_adult'] ; ?> </div>
                </div>

                <div class="parts ninenty_centered no_shade_noBorder btn_book_now_box">
                    <button data-room="<?php echo $row['room_id']; ?>" class="btn_book_now">    Book Now</button>
                </div>
                <?php
            }
        } else {
            echo '<div classs="whilte_text xx_titles">No records found!</div>';
        }
        ?>
        <?php
        $this->get_booked();
    }

    function get_booked() {//This is js
        ?>
        <script>
            $('.btn_book_now').click(function () {
                $('#room_id').val($(this).data('room'));
                $('.btn_book_now_box, .room_data_res').slideUp(100, function () {
                    $('.personal_info_pane').slideDown(120);
                });

            });
            $('.btn_personal_info').click(function () {
                var roomid = $('#room_id').val();
                var name = $('#txt_name').val();
                var last_name = $('#txt_last_name').val();
                var email = $('#txt_email').val();
                var make_reservation = '';
                if (name != '' && last_name != '' && email != '') {
                    $.post('admin/handler.php', {
                        make_reservation: make_reservation,
                        checkin: checkin,
                        checkout: checkout,
                        roomid: roomid,
                        name: name,
                        last_name: last_name,
                        email: email},
                            function (data) {
                                console.log('Data: ' + data);
                            }).complete(function () {
                        $('.only_data, .personal_info_pane').fadeOut(100, function () {
                            $('.done_pane').show();
                            $('#title').html('Provide your personal information');
                        });
                    });
                } else {
                    $('#title').html('You have to fill all the records').addClass('red_message');
                }

            });

        </script>
        <?php
    }

    function get_last_image_id() {

        $con = new dbconnection();
        $sql = "select      image.image_id as id from image order by image_id desc limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['id'];
        return $userid;
    }

    function get_cat_by_catname($name) {
        $con = new dbconnection();
        $sql = "select account.account_id, account_category.name,account_category.account_category_id from account 
                join account_category on account.account_category=account_category.account_category_id
                where account_category.name=:name";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":name" => $name));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_category_id'];
        return $userid;
    }
    function get_price_by_reservation($name) {
        $con = new dbconnection();
        $sql = "select room.price_per_night, reservation.reservation_id from reservation 
                join room on room.room_id=reservation.room
                where reservation.reservation_id=:reservation ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":reservation" => $name));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['price_per_night'];
        return $userid;
    }

    function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }

}

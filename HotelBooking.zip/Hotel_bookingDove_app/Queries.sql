 
SELECT * FROM hotel_booking_dove.reservation
join account on account.account_id=reservation.guest
join account_category on account_category.account_category_id=account.account_category
join profile on profile.profile_id=account.profile
join room on room.room_id=reservation.room

join checkin on checkin.reservation=reservation.reservation_id

join checkout on checkout.reservation=reservation.reservation_id




;


-- reservation is up to reservation

-- checkin is up to che

